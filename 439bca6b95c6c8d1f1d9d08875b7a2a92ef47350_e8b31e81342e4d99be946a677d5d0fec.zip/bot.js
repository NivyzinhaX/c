const { Client, GatewayIntentBits } = require('discord.js');
const express = require('express');
const fs = require('fs-extra');
const axios = require('axios');
const config = require('./config.json');
const path = require('path');

const bot = new Client({
    intents: [GatewayIntentBits.Guilds, GatewayIntentBits.GuildMembers]
});

// Comandos do bot
bot.commands = new Map();
const loadCommands = () => {
    const commandFiles = fs.readdirSync('./commands').filter(file => file.endsWith('.js'));
    let registeredCommands = [];
    
    for (const file of commandFiles) {
        try {
            const command = require(`./commands/${file}`);
            if (command.data && command.data.name) {
                bot.commands.set(command.data.name, command);
                registeredCommands.push(command.data.name);
            } else {
                console.warn(`O comando no arquivo ${file} está mal formatado ou não possui "data.name".`);
            }
        } catch (error) {
            console.error(`Erro ao carregar o comando em ${file}:`, error);
        }
    }
    
    console.log("Comandos registrados:", registeredCommands.length > 0 ? registeredCommands.join(', ') : "Nenhum comando registrado.");
};
loadCommands();

// Carregar events
const eventsPath = path.join(__dirname, 'events');
fs.readdirSync(eventsPath).forEach(file => {
    if (file.endsWith('.js')) {
        const event = require(`./events/${file}`);
        if (event.once) {
            bot.once(event.name, (...args) => event.execute(...args));
        } else {
            bot.on(event.name, (...args) => event.execute(...args));
        }
    }
});

// Interação com comandos
bot.on('interactionCreate', async interaction => {
    if (!interaction.isCommand()) return;
    const command = bot.commands.get(interaction.commandName);
    if (command) {
        try {
            await command.execute(interaction, bot);
        } catch (error) {
            console.error(`Erro ao executar o comando ${interaction.commandName}:`, error);
            await interaction.reply({ content: 'Houve um erro ao executar este comando.', ephemeral: true });
        }
    } else {
        console.warn(`O comando "${interaction.commandName}" não foi encontrado.`);
    }
});

bot.once('ready', () => {
    console.log(`${bot.user.tag} está online!`);
});

// Login do bot
bot.login(config.token);

// Servidor Express para OAuth2
const app = express();
app.use(express.json());

app.get('/callback', async (req, res) => {
    const code = req.query.code;
    if (!code) return res.send('Código inválido.');

    try {
        const tokenResponse = await axios.post('https://discord.com/api/oauth2/token', new URLSearchParams({
            client_id: config.clientId,
            client_secret: config.clientSecret,
            grant_type: 'authorization_code',
            code,
            redirect_uri: config.redirectUri
        }), {
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' }
        });

        const accessToken = tokenResponse.data.access_token;
        const userResponse = await axios.get('https://discord.com/api/users/@me', {
            headers: { Authorization: `Bearer ${accessToken}` }
        });

        const user = userResponse.data;
        const memberData = { id: user.id, accessToken, username: user.username + "#" + user.discriminator };

        let membros = [];
        if (fs.existsSync('./DatabaseJson/Membros.json')) {
            const rawData = fs.readFileSync('./DatabaseJson/Membros.json');
            membros = JSON.parse(rawData).membros || [];
        }

        if (!membros.find(m => m.id === user.id)) {
            membros.push(memberData);
            fs.writeFileSync('./DatabaseJson/Membros.json', JSON.stringify({ membros }, null, 4));
        }

        res.sendFile(path.join(__dirname, 'redirect.html'));

    } catch (error) {
        console.error(error);
        res.send('Erro ao processar a verificação.');
    }
});

app.listen(3000, () => console.log('Servidor OAuth rodando na porta 3000'));