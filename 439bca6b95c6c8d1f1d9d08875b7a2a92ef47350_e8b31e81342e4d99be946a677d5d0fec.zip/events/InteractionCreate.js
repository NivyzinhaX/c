module.exports = {
    name: 'interactionCreate',
    async execute(interaction) {
        if (!interaction.isCommand()) return;

        const command = interaction.client.commands.get(interaction.commandName);
        if (!command) return;

        try {
            await command.execute(interaction);
        } catch (error) {
            console.error(`Erro ao executar ${interaction.commandName}:`, error);
            await interaction.reply({ content: '❌ Ocorreu um erro ao executar o comando.', ephemeral: true });
        }
    }
};