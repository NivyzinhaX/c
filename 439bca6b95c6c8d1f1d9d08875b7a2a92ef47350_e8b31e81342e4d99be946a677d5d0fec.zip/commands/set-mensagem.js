const { SlashCommandBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const config = require('../config.json');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('set-mensagem')
        .setDescription('Envia a mensagem de verificação (somente para o owner).'),
    async execute(interaction) {
        if (interaction.user.id !== config.ownerId) {
            return interaction.reply({ content: 'Você não tem permissão para usar este comando!', ephemeral: true });
        }

        const authUrl = `https://discord.com/oauth2/authorize?client_id=${config.clientId}&redirect_uri=${encodeURIComponent(config.redirectUri)}&response_type=code&scope=identify%20guilds.join`;

        const row = new ActionRowBuilder().addComponents(
            new ButtonBuilder()
                .setLabel('Verificação')
                .setStyle(ButtonStyle.Link)
                .setURL(authUrl)
        );

        await interaction.channel.send({ content: 'Mensagem: Verifica aí Bebê', components: [row] });
        await interaction.reply({ content: 'Mensagem de verificação enviada!', ephemeral: true });
    }
};