const { SlashCommandBuilder } = require('discord.js');
const fs = require('fs');
const axios = require('axios');
const config = require('../config.json');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('puxar-all')
        .setDescription('Puxa todos os membros verificados para um servidor.')
        .addStringOption(option =>
            option.setName('server_id')
                .setDescription('ID do servidor de destino')
                .setRequired(true)
        ),
    async execute(interaction) {
        // Verifica se o usuário é o dono
        if (interaction.user.id !== config.ownerId) {
            return interaction.reply({ content: '❌ Você não tem permissão para usar este comando!', ephemeral: true });
        }

        const serverId = interaction.options.getString('server_id');
        const botToken = config.token;

        const guild = interaction.client.guilds.cache.get(serverId);
        if (!guild) {
            return interaction.reply({ content: '❌ O bot não está no servidor informado.', ephemeral: true });
        }

        let membrosData;
        try {
            const rawData = fs.readFileSync('./DatabaseJson/Membros.json');
            membrosData = JSON.parse(rawData).membros;
        } catch (error) {
            return interaction.reply({ content: '❌ Erro ao ler os membros verificados.', ephemeral: true });
        }

        if (!membrosData || membrosData.length === 0) {
            return interaction.reply({ content: '⚠️ Nenhum membro verificado encontrado.', ephemeral: true });
        }

        await interaction.reply(`🔄 Iniciando o processo de puxar ${membrosData.length} membros...`);

        let puxados = 0, falhas = 0;

        for (const membro of membrosData) {
            try {
                await axios.put(`https://discord.com/api/v10/guilds/${serverId}/members/${membro.id}`, {
                    access_token: membro.accessToken
                }, {
                    headers: { Authorization: `Bot ${botToken}`, 'Content-Type': 'application/json' }
                });

                puxados++;
            } catch (error) {
                console.error(`Erro ao puxar ${membro.username}:`, error.response?.data || error.message);
                falhas++;
            }
        }

        await interaction.followUp(`✅ Sucesso: ${puxados}\n❌ Falhas: ${falhas}`);
    }
};